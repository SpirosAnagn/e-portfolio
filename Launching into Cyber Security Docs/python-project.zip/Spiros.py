import hashlib, os, binascii, re, mysql.connector

""" The first three libraries (hashlib, os and binascii) will be used for hash-salting the password,
    while the re library will be used for matching regular expressions with strings. 
    The "mysql.connector" is an SQL manipulation library for python and 
    it will be used in the final part of the program"""

""" The program starts with a loop that asks the user to set his/her username.
    Special rules are taking place to break the loop and proceed to the next step.
    For example, the first 'if' demands characters to be at least eight but no more than twenty.
    The second one (elif) uses the re library to match for at least one capital letter, 
    and the loop continues until every condition is fulfilled """

while True:
    initial_username = input("Please set your username: ")
    is_ok = False

    if (len(initial_username) < 8 or len(initial_username) > 20):
        print("Your username should be between 8 and 20 characters long")
        continue
    elif not re.search("[A-Z]", initial_username):
        print("Not valid! Your username must contain at least one letter from [A-Z]")
        continue
    elif not re.search("[a-z]", initial_username):
        print("Not valid! Your username must contain at least one letter from [a-z]")
        continue
    elif not re.search("[1-9]", initial_username):
        print("Your username must contain at least one digit")
        continue
    else:
        is_ok = True
        break

""" Having set the username, we reach the second loop, which is similar to the previous one. 
    One additional rule (line 54) has been established that asks the user to insert one of 
    the special characters printed """

while True:
    initial_password = input("Please set your password: ")
    is_valid = False

    if (len(initial_password) < 8 or len(initial_password) > 20):
        print("Your password should be between 8 and 20 characters long")
        continue
    elif not re.search("[A-Z]", initial_password):
        print("Not valid! Your password must contain at least one letter from [A-Z]")
        continue
    elif not re.search("[a-z]", initial_password):
        print("Not valid! Your password must contain at least one letter from [a-z]")
        continue
    elif not re.search("[1-9]", initial_password):
        print("Your password must contain at least one digit")
        continue
    elif not re.search("[!@#$%^&*()_+=]", initial_password):
        print("Your password must contain at least one of these special symbols: ! @ # $ % ^ & * ( ) _ + = ")
        continue
    else:
        is_valid = True
        break

if is_valid:
    print("Password saved!")

""" The last loop checks that the email input is not blank, and if the user inserts something 
    into this part, the loop breaks. """

while True:
    email_set = input("Please insert a valid email: ")
    not_blank = False

    if email_set == "":
        continue
    else:
        not_blank = True
        break
c = email_set

""" In the following part a function (hash_pass) is defined that gets the initial user's password input as an argument.
    The salt parameter uses hashlib's sha256 method and os urandom (better randomness than default random which depends 
    on the Operating System) to produce a random key. With pbkdf2_hmac method we get a random predefined length key 
    based on the password, the salt and the number of iterations (100000 in this case).
    At the next step, binascii.hexlify transforms the previous binary output to hexadecimal form and
    finally we get a 192 character string that is our user's password from now on."""


def hash_pass(initial_password):
    salt = hashlib.sha256(os.urandom(60)).hexdigest().encode("utf-8")
    initial_password = hashlib.pbkdf2_hmac('sha512', initial_password.encode("utf-8"), salt, 100_000)
    initial_password = binascii.hexlify(initial_password)
    return (salt + initial_password).decode("utf-8")


""" The previous inputs are stored in a,b and c (line 76) variables """

a = str(initial_username)
b = str(hash_pass(initial_password))

""" The following part is about SQL setup and passing the previous variables inside the table Users"""

""" 1.Connection with Database with the mysql.connector, using the appropriate credentials"""

mydb = mysql.connector.connect(
    host='127.0.0.1',
    user='root',
    password='codio')

mycursor = mydb.cursor()

""" 2. A new DATABASE named Asmis is created """

mycursor.execute("CREATE DATABASE IF NOT EXISTS Asmis")
mydb.commit()

mycursor.execute("USE Asmis")

""" 3. A new table Users is created with UseID as the primary key (increments automatically), username,
    password and mail """

query1 = "CREATE TABLE IF NOT EXISTS Users (UserId INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(255),\
          password VARCHAR(255), email VARCHAR(255))"

mycursor.execute(query1)
mydb.commit()

""" 4. The previous variables a, b and c are inserted into User's table. """

query2 = "INSERT INTO Users (username, password, email) VALUES (%s, %s, %s)"
data = a, b, c
mycursor.execute(query2, data)
mydb.commit()

print(mycursor.rowcount, "record inserted.")
mycursor = mydb.cursor()

""" 5. The final result is printed for testing purposes"""

sql = "SELECT * FROM Users ORDER BY UserId"
mycursor.execute(sql)
myresult = mycursor.fetchall()
for x in myresult:
    print(x)
