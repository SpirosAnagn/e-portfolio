**Description:**  	
------------------------------------------------------------------------------------------------------
 

This program aims to use a secure way (not plain text) to store user passwords in a Database without using the default Database's encryption methods.

  
The first part consists of 3 loops that include some prerequisites for setting up a new User.
The scope of this part is to establish a password security policy (minimum characters, mandatory use of capital letters and numbers etc.).
In the second part, a function (hash_pass) takes the password input, which meets the previous rules and transforms it into a hash-salted string.
In the final part, the script’s output (username, hash-salted password and email) become the input for our Asmis Database for every new user addition.

The final result is a row with UserId (increments automatically) username, hash-salted password and email.



**_Prerequisites:_**

Python 3 and MySQL (Linux or Windows)



**How to execute the program:**
------------------------------------------------------------------------------------------------------

_Windows:_


a) Install MySQL:
https://dev.mysql.com/downloads/installer/

Set up your SQL Server with the following credentials:
username : root
password: codio



b) Install python3:
https://www.python.org/downloads/


Click Spiros.py and open with Python

------------------------------------------------------------------------------------------------------

_Linux:_


a) Install python3:

https://linuxize.com/post/how-to-install-python-3-9-on-ubuntu-20-04/


b) Install MySQL connector:

From the terminal (Ctrl + Alt + T):

1) pip3 install mysql-connector-python  (Enter)

2) python3                              (Enter)

3) import mysql.connector               (Enter)

4) Type " python3 Spiros.py " in the terminal to execute the script. (Enter)

------------------------------------------------------------------------------------------------------



The script in the file Spiros works as a single-file program.
Insert a new username (see instructions in case of invalid input)
Insert a password for the new user (see instructions in case of invalid input)
Insert mail (not blank)
New User has been created, and the database entry is displayed for testing the final result.

------------------------------------------------------------------------------------------------------
**Disclaimer:**

The credentials for the SQL connection are included in the program for the assignment's purpose.
In the real world, this is not a secure practice and should be strictly avoided.



------------------------------------------------------------------------------------------------------
**References:**


CodeVsColor. (N.D.) Python program to take user input and check validity of a password.
Available from: https://www.codevscolor.com/python-check-validity-password [Accessed 6 April 2021].

Oracle Corporation. (N.D.) MySQL Connector/Python Developer Guide 
Available from: https://dev.mysql.com/doc/connector-python/en/ [Accessed: 8 April 2021]

Python Software Foundation. (N.D.) hashlib — Secure hashes and message digests 
Available from: https://docs.python.org/3/library/hashlib.html [Accessed 12 April 2021]

Python Software Foundation. (N.D.) os — Miscellaneous operating system interfaces.
Available from: https://docs.python.org/3/library/os.html [Accessed 5 April 2021]

Python Software Foundation. (N.D.) re — Regular expression operations  
Available from: https://docs.python.org/3/library/re.html [Accessed 8 April 2021]

Vitoshacademy. (2018) Hashing Passwords in Python.
Available from: https://www.vitoshacademy.com/hashing-passwords-in-python/ [Accessed 6 April 2021]. 

W3Schools. (N.D.) Python MySQL. Available from: https://www.w3schools.com/python/python_mysql_getstarted.asp [Accessed 10 April 2021].








